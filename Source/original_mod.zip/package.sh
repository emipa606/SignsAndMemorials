#!/usr/bin/bash

HEAD=../Signs_and_Memorials

zip -vr ./Signs_and_Memorials.zip  $HEAD/About $HEAD/Assemblies $HEAD/Defs $HEAD/Languages $HEAD/Textures
