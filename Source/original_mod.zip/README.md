# RimWorld - Signs and Memorials
RimWorld mod that adds editable signs and memorials

[Ludeon Forum post](https://ludeon.com/forums/index.php?topic=29773.0)

## Install
You can grab a copy of this mod in the [releases section](https://github.com/MCManuelLP/RimWorld-Signs_and_Memorials/releases), or if you prefer using the Steam Workshop, [this mod](http://steamcommunity.com/sharedfiles/filedetails/?id=846276095) is available over there as well!
